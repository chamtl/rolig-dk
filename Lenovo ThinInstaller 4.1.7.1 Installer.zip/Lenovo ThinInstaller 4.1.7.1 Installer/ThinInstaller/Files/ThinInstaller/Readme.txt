Lenovo Thin Installer
for Windows 7, Windows 10, Windows 11
Version 1.04.02.0024
Installation Readme


Thin Installer is a smaller version of System Update.
Thin Installer searches for the update packages from a repository 
that you create. The repository can be created on your local
hard drive, a network share or external media such as a CD, DVD,
or USB hard drive.

When Thin Installer finishes installing applicable packages, 
no registry keys related to Thin Installer would be generated - thus the user 
only needs to delete the folder containing Thin Installer to remove 
all files associated with Thin Installer and the associated repository.

New in 2024-09-04 release
=========================
- Support HTML Readme files
- Add "-ignorexmlsignature" parameter to commandline, to ignore signature check on XMLs
- Include InstallDate item in WMI history
- Verify package XML digital signatures
- Remove XML schema check
- Remove SHA-1 hash algorithm support
- Fix several issues

New in 2022-12-01 release
=========================
- Rccancel attribute added on Install element
- PcdDescriptor attribute added on Package element

New in 2022-06-11 release
=========================
- Support firmware version hex comparison
- Update CV to 3.1.25
- Fix several issues

New in 2022-04-21 release
=========================
- Commandline filters expanded to support -includerebootpackages and -packagetypes on LIST and SCAN actions.
- Support limit runtime of external detection routines.
- Fix several issues

New in 2022-02-11 release
=========================
- Update CV to 3.1.24
- Fix several issues

New in 2021-10-29 release
=========================
- Update Internal method to detect Win11 build

New in 2021-09-22 release
=========================
- Add support for Windows 11
- Update CV to 3.1.22
- Fix bug in Embedded Controller identifier

New in 2021-07-13 release
=========================
- Update CV to 3.1.20
- Support firmware version detection
- Fix several issues

New in 2021-02-05 release
=========================
- Update CV to 3.1.18

New in 2020-09-29 release
=========================
- Add Internal method to detect Win10 build
- Support TLS1.2/HTTPS
- Provide return codes even when -showprogress is used
- Fix several issues

New in 2020-06-29 release
=========================
- Update Lenovo Certificate Validation to the latest

New in 2019-12-19 release
=========================
- Add option download updates only, commandline parameter: -download, -installdeferred
- Add return code for specific scenario
- Add commandline parameter: -packagetypes
- Fix several issues

New in 2019-08-01 release
=========================
- Fix search issue in Thai region
- Fix BSOD issue in Win10 RS6

New in 2019-04-25 release
-Support new reboot type.

New in 2019-02-01 release
- add option to not continue install after reboot, commandline parameter: -nocontinueafterreboot
- add Severity property in WMI.
- fix log related bugs.

New in 2018-08-03 release
fix some bugs

New in 2018-07-31 release
- add "-nocancel" parameter to commandline, to disable cancel button in show progress page.
- add "-exporttowmi" parameter to commandline, to export update history to WMI. 

New in 2017-11-08 release
- fix certificates verify failed

New in 2017-09-20 release
- fix some issues

New in 2017-08-31 release
- fix some issues

New in 2017-08-22 release
- fix TI intermittent crash

New in 2017-07-27 release
- fix some issues

New in 2017-07-18 release
- fix some issues

New in 2017-06-26 release
- fix some issues

New in 2017-06-13 release
- fix some issues

New in 2017-05-25 release
- fix some issues

New in 2017-05-16 release
- fix some issues

New in 2017-05-05 release
- fix some issues

New in 2017-02-13 release
- fix some issues

New in 2016-11-18 release
- fix some issues

New in 2016-07-05 release
- fix some issues

New in 2016-04-28 release
- fix some issues

New in 2015-11-05 release
- fix some issues

New in 2015-07-24 release
- supports Windows 10

New in 2013-10-29 release
- supports Windows 8.1

New in 2013-03-20 release
- supports Windows 8
- supports 10-digit machine type model

New in 2012-9-28 release
- supports 64bit INF driver installation

New in 2011-9-14 release
- supports UEFI BIOS

New in 2009-12-9 release
- supports Windows 7

New in 2009-10-9 release
=======================
- supports HTTP-based repository
- maintains the history of each update in a separate log file

New in 2009-8-31 release
=======================
- supports Vista Service Pack 2
- In previous versions of Thin Installer, during installation of some
  updates like wired LAN adapter,it resets the system's network subsystem
  and terminates Thin Installer's link to the share of repository drivers,
  preventing Thin Installer from installing any more drivers from
  the share. This problem is corrected in this release.
- An optional command line parameter, -showprogress, is added to display
  search and installation progress. 


Supported systems
=================
Lenovo Thin Installer is supported on the following systems:

- All ThinkPad computers
- All ThinkCentre desktop computers 
- All ThinkStation computers
- All OEM computers

Lenovo Thin Installer supports additional systems as content is
created for them.


Software requirements
=====================
The following operating systems are supported: 
- Microsoft Windows 7 (32-bit and 64-bit)
- Microsoft Windows 10 (32-bit and 64-bit)
- Microsoft Windows 11

Downloading the package
=======================
1. Click the file links to download the files from the Web page.
2. When prompted, select a drive and directory in which to save the
   downloaded files.


Installing the package
======================
The installer is self-Extraction software, which is used as a standalone 
installation utility that runs without an installation process (e.g. no 
registry keys or services are required).

Under Windows 10 or Windows 11
---------------------------
1. Open File Explorer.
2. Click "This PC" on the left panel.
3. Type lenovothininstaller1.04.02.0024-2024-09-04.exe in the search field on the upper right corner. This will locate the file you just downloaded.
4. Double-click the executable icon. You might see a dialog stating "Do you want to allow this app to make changes to your PC?". If you see this dialog, click Continue.
5. Follow the onscreen instructions to complete the installation.

Under Windows 7
---------------------------
1. Click Start, then click Start Search.
2. Type lenovothininstaller1.04.02.0024-2024-09-04.exe in the search field, then click Search Everywhere. This will locate the file you just downloaded.
3. Double-click the executable icon. You might see a dialog stating "Do you want to allow the following program to make changes to this computer?". If you see this dialog, click Continue.
4. Follow the onscreen instructions to complete the installation.


Trademarks
==========
The following terms are trademarks of Lenovo in the United States, other
countries, or both:

Lenovo
ThinkCentre
ThinkPad
ThinkServer

Microsoft, Windows are trademarks or registered 
trademarks of Microsoft Corporation in the United States, other countries
or both.

Other company, product, and service names may be trademarks or service marks
of others.

LENOVO PROVIDES THIS PUBLICATION "AS IS" WITHOUT WARRANTY OF ANY KIND,
EITHER EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY OR FITNESS FOR A
PARTICULAR PURPOSE. Some jurisdictions do not allow disclaimer of express or
implied warranties in certain transactions, therefore, this statement may not
apply to you. This information could include technical inaccuracies or
typographical errors. Changes are periodically made to the information herein;
these changes will be incorporated in new editions of the publication. Lenovo
may make improvements and/or changes in the product(s) and/or the program(s)
described in this publication at any time without notice.

BY FURNISHING THIS DOCUMENT, LENOVO GRANTS NO LICENSES TO ANY PATENTS OR
COPYRIGHTS.

(C) Copyright Lenovo 2024. All rights reserved.