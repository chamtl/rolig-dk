﻿<#

.SYNOPSIS
PSAppDeployToolkit - This script performs the installation or uninstallation of an application(s).

.DESCRIPTION
- The script is provided as a template to perform an install, uninstall, or repair of an application(s).
- The script either performs an "Install", "Uninstall", or "Repair" deployment type.
- The install deployment type is broken down into 3 main sections/phases: Pre-Install, Install, and Post-Install.

The script imports the PSAppDeployToolkit module which contains the logic and functions required to install or uninstall an application.

PSAppDeployToolkit is licensed under the GNU LGPLv3 License - (C) 2025 PSAppDeployToolkit Team (Sean Lillis, Dan Cunningham, Muhammad Mashwani, Mitch Richters, Dan Gough).

This program is free software: you can redistribute it and/or modify it under the terms of the GNU Lesser General Public License as published by the
Free Software Foundation, either version 3 of the License, or any later version. This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License
for more details. You should have received a copy of the GNU Lesser General Public License along with this program. If not, see <http://www.gnu.org/licenses/>.

.PARAMETER DeploymentType
The type of deployment to perform.

.PARAMETER DeployMode
Specifies whether the installation should be run in Interactive (shows dialogs), Silent (no dialogs), or NonInteractive (dialogs without prompts) mode.

NonInteractive mode is automatically set if it is detected that the process is not user interactive.

.PARAMETER AllowRebootPassThru
Allows the 3010 return code (requires restart) to be passed back to the parent process (e.g. SCCM) if detected from an installation. If 3010 is passed back to SCCM, a reboot prompt will be triggered.

.PARAMETER TerminalServerMode
Changes to "user install mode" and back to "user execute mode" for installing/uninstalling applications for Remote Desktop Session Hosts/Citrix servers.

.PARAMETER DisableLogging
Disables logging to file for the script.

.EXAMPLE
powershell.exe -File Invoke-AppDeployToolkit.ps1 -DeployMode Silent

.EXAMPLE
powershell.exe -File Invoke-AppDeployToolkit.ps1 -AllowRebootPassThru

.EXAMPLE
powershell.exe -File Invoke-AppDeployToolkit.ps1 -DeploymentType Uninstall

.EXAMPLE
Invoke-AppDeployToolkit.exe -DeploymentType "Install" -DeployMode "Silent"

.INPUTS
None. You cannot pipe objects to this script.

.OUTPUTS
None. This script does not generate any output.

.NOTES
Toolkit Exit Code Ranges:
- 60000 - 68999: Reserved for built-in exit codes in Invoke-AppDeployToolkit.ps1, and Invoke-AppDeployToolkit.exe
- 69000 - 69999: Recommended for user customized exit codes in Invoke-AppDeployToolkit.ps1
- 70000 - 79999: Recommended for user customized exit codes in PSAppDeployToolkit.Extensions module.

.LINK
https://psappdeploytoolkit.com



############# OK Run commands ##################

Remidation script from Intune: Invoke-ServiceUI.ps1 -DeploymentType Install -DeployMode Interactive

Manual start from Company portal: Invoke-ServiceUI.ps1 -DeploymentType Repair -DeployMode Interactive

CAPA installer: Invoke-ServiceUI.ps1 -DeploymentType 'Uninstall' -DeployMode Silent -DeployMode NonInteractive

################################################
################################################
################################################
################################################

CHANGE LOG:

2025-10-24, CLBH, V5.3.2.8_4.0.6:
 1. Changed versening to "HPIA_VERSION.INTERNAL.RELEASE_PSADT_VERSION"
 2. Added "Firmware" to /Category install parameter
 3. Added "BIOS,Drivers,Firmware" to /Category analyse parameter
 4. Added OK logo to dialog boxes

2025-10-24, CLBH, V5.3.2.7 :
- 5.3.2.7, CLBH: Added "/Category:BIOS,Drivers" to install command % removed "/Selection:Critical,Recommended" from install command + added "Show-ADTInstallationProgress" to manual Analyse / install

21-10-2025:
- 5.3.2.6, CLBH: Changed to only Critical & Recomended updates is installed.

21-10-2025:
- 5.3.2.5, CLBH: Changed to only Recomended updates is installed.

21-10-2025:
- 5.3.2.4, CLBH: Changed so it is only critical updates that is installed.

5.3.2.3;CLBH: Changed reboot coutdown from 1 hour to 4 hours

################################################

#>

[CmdletBinding()]
param
(
    [Parameter(Mandatory = $false)]
    [ValidateSet('Install', 'Uninstall', 'Repair')]
    [PSDefaultValue(Help = 'Install', Value = 'Install')]
    [System.String]$DeploymentType,

    [Parameter(Mandatory = $false)]
    [ValidateSet('Interactive', 'Silent', 'NonInteractive')]
    [PSDefaultValue(Help = 'Interactive', Value = 'Interactive')]
    [System.String]$DeployMode,

    [Parameter(Mandatory = $false)]
    [System.Management.Automation.SwitchParameter]$AllowRebootPassThru,

    [Parameter(Mandatory = $false)]
    [System.Management.Automation.SwitchParameter]$TerminalServerMode,

    [Parameter(Mandatory = $false)]
    [System.Management.Automation.SwitchParameter]$DisableLogging
)


##================================================
## MARK: Variables
##================================================

$adtSession = @{
    # App variables.
    AppVendor = 'HP'
    AppName = 'Driver Installation'
    AppVersion = '5.3.2.8_4.0.6'
    AppArch = ''
    AppLang = 'EN'
    AppRevision = '01'
    AppSuccessExitCodes = @(0)
    AppRebootExitCodes = @(1641, 3010)
    AppScriptVersion = '8.0.0'
    AppScriptDate = '2025-10-21'
    AppScriptAuthor = 'CLBH'

    # Install Titles (Only set here to override defaults set by the toolkit).
    InstallName = ''
    InstallTitle = ''

    # Script variables.
    DeployAppScriptFriendlyName = $MyInvocation.MyCommand.Name
    DeployAppScriptVersion = '6.0.6'
    DeployAppScriptParameters = $PSBoundParameters
}





        $RunTimeData = Get-date -Format "yyyyMMddHHmm"	
        $ReportFolder = 'C:\HPIA\HPIAReport-' + $RunTimeData + '.html'
        $Softpaqdownloadfolder = 'C:\HPIA\HPIASoftpaqs'
        $ResultAnalyseFile = 'C:\HPIA\HPIAResult_Analyse-' + $RunTimeData + '.html'
        $ResultInstallFile = 'C:\HPIA\HPIAResult_Install-' + $RunTimeData + '.html'
        $HPIAinstalled = ${Env:ProgramData} + '\HPIA\Invoke-AppDeployToolkit.exe'
        $DialogTitle = 'HP Driver Installation'


        #Removed as not needed -  /Selection:Critical,Recommended
		$GeneralParameters = "/Silent /Operation:Analyze /ReportFilePath:`"$ReportFolder`" /softpaqdownloadfolder:`"$Softpaqdownloadfolder`" /Debug"
		$AnalyseParameters = "/Action:Download /Category:BIOS,Drivers,Firmware /ResultFilePath:`"$ResultAnalyseFile`" $GeneralParameters" #Changed from List to Download to get it to download missing softpaqs before it ask users to stop working
		$InstallParameters = "/Action:Install /Category:BIOS,Drivers,Firmware /AutoCleanup /ResultFilePath:`"$ResultInstallFile`" $GeneralParameters"






function Install-ADTDeployment
{
    ##================================================
    ## MARK: Pre-Install
    ##================================================
    $adtSession.InstallPhase = "Pre-$($adtSession.DeploymentType)"

    ## Show Welcome Message, close Internet Explorer if required, allow up to 3 deferrals, verify there is enough disk space to complete the install, and persist the prompt.
#    Show-ADTInstallationWelcome -CloseProcesses iexplore -AllowDefer -DeferTimes 3 -CheckDiskSpace -PersistPrompt

    ## Show Progress Message (with the default message).
#    Show-ADTInstallationProgress

    ## <Perform Pre-Installation tasks here>




                #Check if HPIA is installed
                if (!(Test-Path $HPIAinstalled))
                {
                    Write-ADTLogEntry -Message 'HPIA is not installed! Exiting.'
                    Close-ADTSession -Exitcode 0
                }
                

                Get-ADTPendingReboot


                If ((Get-BitLockerVolume).VolumeStatus -contains 'EncryptionInProgress')
		        {
			        #Bitlocker Encryption is in progress, do not risk to trigger BIOS upgrade during will try again later
			        Write-ADTLogEntry -Message 'Bitlocker encryption in progress, will skip'
			        Close-ADTSession -Exitcode 0
		        }
		        else
		        {
			        #Run HPIA in Analyse Mode to detect if we need to update drivers
			        Show-ADTBalloonTip -BalloonTipText 'Checking for HP Driver Updates'
			        Write-ADTLogEntry -Message "Running HPIA to analyze for new drivers - check HP Image Assistant Log for details"
			        $RunCommand = Start-ADTProcess -FilePath 'HPImageAssistant.exe' -ArgumentList $AnalyseParameters -PassThru -IgnoreExitCodes 256,257,4098
			

			        If ($RunCommand.Exitcode -in (256, 257))
			        {
				        #The analysis returned no recommendations. 
				        Write-ADTLogEntry -Message 'The analysis returned no recommendations'
				        Show-ADTBalloonTip -BalloonTipText 'HP Drivers is Updated'
				        #End Installation
				        Close-ADTSession -Exitcode 0
			        }
			        elseif ($RunCommand.Exitcode -notin (4098, 0))
			        {
				        Write-ADTLogEntry -Message "Unexpected exitcode $($RunCommand.Exitcode) received from HPIA"
				        Close-ADTSession -Exitcode $RunCommand.Exitcode
			        }
			        elseif ($RunCommand.ExitCode -eq 4098)
			        {
				        #There is no Internet connection.
				        Write-ADTLogEntry -Message 'HPIA returned 4098 - There is no Internet connection.'
				        Show-ADTBalloonTip -BalloonTipText 'No Internet Connection detected - Cannot check for HP drivers.'
				        Close-ADTSession -ExitCode $RunCommand.ExitCode
			        }
		        }


    ##================================================
    ## MARK: Install
    ##================================================
    $adtSession.InstallPhase = $adtSession.DeploymentType

    ## Handle Zero-Config MSI installations.
    if ($adtSession.UseDefaultMsi)
    {
        $ExecuteDefaultMSISplat = @{ Action = $adtSession.DeploymentType; FilePath = $adtSession.DefaultMsiFile }
        if ($adtSession.DefaultMstFile)
        {
            $ExecuteDefaultMSISplat.Add('Transform', $adtSession.DefaultMstFile)
        }
        Start-ADTMsiProcess @ExecuteDefaultMSISplat
        if ($adtSession.DefaultMspFiles)
        {
            $adtSession.DefaultMspFiles | Start-ADTMsiProcess -Action Patch
        }
    }

    ## <Perform Installation tasks here>

                
                #Starting to install updates.
                Write-ADTLogEntry -Message 'Starting to install updates.'
                Show-ADTInstallationProgress -StatusMessage "Installing HP Driver Updates....This might take a while."
                $RunCommand = Start-ADTProcess -FilePath 'HPImageAssistant.exe' -ArgumentList $InstallParameters -PassThru -IgnoreExitCodes 256,257,3010,3020,4098


    ##================================================
    ## MARK: Post-Install
    ##================================================
    $adtSession.InstallPhase = "Post-$($adtSession.DeploymentType)"

    ## <Perform Post-Installation tasks here>






		        If ($RunCommand.ExitCode -eq 3010 -or (Get-ADTPendingReboot).IsSystemRebootPending -eq 'True') #Reboot required
		        {
			
			        Write-ADTLogEntry -Message "Triggered Restart Program"
			
			        If ($DeployMode -eq 'Interactive')
			        {
				        Write-ADTLogEntry -Message 'Showing Restart prompt to user as HPIA returned 3010 or a reboot is requered'
				        Show-ADTInstallationRestartPrompt -CountdownSeconds 14400 -CountdownNoHideSeconds 300 #Restart automatically within 4 hour, user cannot minimize prompt last 5 minutes.
				        Close-ADTSession -ExitCode 3010
			        }
		        }
		        Elseif ($RunCommand.ExitCode -eq 0 -or $RunCommand.ExitCode -eq 256 -or $RunCommand.ExitCode -eq 257)
		        {
			        Show-ADTBalloonTip -BalloonTipText 'Driver update completed. A restart of the computer is recommended.'
			        Write-ADTLogEntry -Message 'Drivers updated.'
			
		        }
		        elseif ($RunCommand.ExitCode -eq 4098)
		        {
			        #There is no Internet connection.
			        Write-ADTLogEntry -Message 'HPIA returned 4098 - There is no Internet connection.'
			        Close-ADTSession -Exitcode $RunCommand.Exitcode
		        }
		        Else
		        {
			        Write-ADTLogEntry -Message 'Unhandled error code from HPIA'
			        Close-ADTSession -Exitcode $RunCommand.Exitcode
		        }


    if (!$adtSession.UseDefaultMsi)
    {

        #Show-ADTInstallationPrompt -Message 'You can customize text to appear at the end of an install or remove it completely for unattended installations.' -ButtonRightText 'OK' -Icon Information -NoWait
    }
}

function Uninstall-ADTDeployment
{
    ##================================================
    ## MARK: Pre-Uninstall
    ##================================================
    $adtSession.InstallPhase = "Pre-$($adtSession.DeploymentType)"

    ## Show Welcome Message, close Internet Explorer with a 60 second countdown before automatically closing.
    #Show-ADTInstallationWelcome -CloseProcesses iexplore -CloseProcessesCountdown 60

    ## Show Progress Message (with the default message).
    #Show-ADTInstallationProgress







    ## <Perform Pre-Uninstallation tasks here>


    ##================================================
    ## MARK: Uninstall
    ##================================================
    $adtSession.InstallPhase = $adtSession.DeploymentType

    ## Handle Zero-Config MSI uninstallations.
    if ($adtSession.UseDefaultMsi)
    {
        $ExecuteDefaultMSISplat = @{ Action = $adtSession.DeploymentType; FilePath = $adtSession.DefaultMsiFile }
        if ($adtSession.DefaultMstFile)
        {
            $ExecuteDefaultMSISplat.Add('Transform', $adtSession.DefaultMstFile)
        }
        Start-ADTMsiProcess @ExecuteDefaultMSISplat
    }

    ## <Perform Uninstallation tasks here>

                
                #Starting to install updates.
                Write-ADTLogEntry -Message 'Starting to install updates.'
                #Show-ADTInstallationProgress -StatusMessage "Installing HP Driver Updates....This might take a while."
                $RunCommand = Start-ADTProcess -FilePath 'HPImageAssistant.exe' -ArgumentList $InstallParameters -PassThru -IgnoreExitCodes 256,257,3010,3020,4098


    ##================================================
    ## MARK: Post-Uninstallation
    ##================================================
    $adtSession.InstallPhase = "Post-$($adtSession.DeploymentType)"

    ## <Perform Post-Uninstallation tasks here>


}

function Repair-ADTDeployment
{
    ##================================================
    ## MARK: Pre-Repair
    ##================================================
    $adtSession.InstallPhase = "Pre-$($adtSession.DeploymentType)"

    ## Show Welcome Message, close Internet Explorer with a 60 second countdown before automatically closing.
    #Show-ADTInstallationWelcome -CloseProcesses iexplore -CloseProcessesCountdown 60

    ## Show Progress Message (with the default message).
    #Show-ADTInstallationProgress

    ## <Perform Pre-Repair tasks here>

                #Check if HPIA is installed
                if (!(Test-Path $HPIAinstalled))
                {
                    Write-ADTLogEntry -Message 'HPIA is not installed! Exiting.'
                    Show-ADTDialogBox -Text "HP Image Assistant is not installed. Install it from the Company Portal and run it this application again" -Icon 'Exclamation' -Buttons 'OK'
                    Close-ADTSession -Exitcode 0
                }

                Get-ADTPendingReboot


                If ((Get-BitLockerVolume).VolumeStatus -contains 'EncryptionInProgress')
		        {
			        #Bitlocker Encryption is in progress, do not risk to trigger BIOS upgrade during will try again later
			        Show-ADTDialogBox -Text 'Bitlocker encryption in progress, will exit' -Icon 'Exclamation' -Buttons 'OK'
                    Write-ADTLogEntry -Message 'Bitlocker encryption in progress, will skip'
			        Close-ADTSession -Exitcode 0
		        }
		        else
		        {
			        #Run HPIA in Analyse Mode to detect if we need to update drivers
			        Show-ADTInstallationProgress -StatusMessage "Checking for HP Driver Updates....."
                    #Show-ADTBalloonTip -BalloonTipText 'Checking for HP Driver Updates.....'
			        Write-ADTLogEntry -Message "Running HPIA to analyze for new drivers - check HP Image Assistant Log for details"
			        $RunCommand = Start-ADTProcess -FilePath 'HPImageAssistant.exe' -ArgumentList $AnalyseParameters -PassThru -IgnoreExitCodes 256,257,4098
                    
                    #Run HPIA in Analyse Mode to detect if we need to update drivers
			        Show-ADTInstallationProgress -StatusMessage "Updating HP Drivers.....This might take a while."
                    #Show-ADTBalloonTip -BalloonTipText 'Checking for HP Driver Updates....'
			        Write-ADTLogEntry -Message "Running HPIA to analyze need for new drivers - check HP Image Assistant Log for details"
			        $RunCommand = Start-ADTProcess -FilePath 'HPImageAssistant.exe' -ArgumentList $InstallParameters -PassThru -IgnoreExitCodes 256,257,3010,3020,4098
    	        }


    ##================================================
    ## MARK: Repair
    ##================================================
    $adtSession.InstallPhase = $adtSession.DeploymentType

    ## Handle Zero-Config MSI repairs.
    if ($adtSession.UseDefaultMsi)
    {
        $ExecuteDefaultMSISplat = @{ Action = $adtSession.DeploymentType; FilePath = $adtSession.DefaultMsiFile }
        if ($adtSession.DefaultMstFile)
        {
            $ExecuteDefaultMSISplat.Add('Transform', $adtSession.DefaultMstFile)
        }
        Start-ADTMsiProcess @ExecuteDefaultMSISplat
    }

    ## <Perform Repair tasks here>




    ##================================================
    ## MARK: Post-Repair
    ##================================================
    $adtSession.InstallPhase = "Post-$($adtSession.DeploymentType)"

    ## <Perform Post-Repair tasks here>


		        If ($RunCommand.ExitCode -eq 3010 -Or (Get-ADTPendingReboot).IsSystemRebootPending -eq 'True') #Reboot required
		        {
			
			        Write-ADTLogEntry -Message "Triggered Restart Program"
			
			        If ($DeployMode -eq 'Interactive')
			        {
				        Write-ADTLogEntry -Message 'Showing Restart prompt to user as HPIA returned 3010 or a reboot is requered'
                        Show-ADTInstallationRestartPrompt -Title $DialogTitle -CountdownSeconds 14400 -CountdownNoHideSeconds 300 #Restart automatically within 4 hour, user cannot minimize prompt last 5 minutes.
				        Close-ADTSession -ExitCode 3010
			        }
		        }
		        Elseif ($RunCommand.ExitCode -eq 0 -or $RunCommand.ExitCode -eq 256 -or $RunCommand.ExitCode -eq 257)
		        {
			        Show-ADTDialogBox -Title $DialogTitle -Text 'Driver update completed. A restart of the computer is recommended.' -Icon 'Exclamation' -Buttons 'OK'
                    #Show-ADTBalloonTip -BalloonTipText 'Driver update completed. A restart of the computer is recommended.'
			        Write-ADTLogEntry -Message 'Drivers updated.'
			
		        }
		        elseif ($RunCommand.ExitCode -eq 4098)
		        {
			        #There is no Internet connection.
			        Write-ADTLogEntry -Message 'HPIA returned 4098 - There is no Internet connection.'
			        Show-ADTDialogBox -Title $DialogTitle -Text 'The Pc is not connected to the Internet. Connect it to the internet and try again.' -Icon 'Exclamation' -Buttons 'OK'
                    Close-ADTSession -Exitcode $RunCommand.Exitcode
		        }
		        Else
		        {
			        Write-ADTLogEntry -Message 'Unhandled error code from HPIA'
			        Show-ADTDialogBox -Title $DialogTitle -Text 'Unhandled error code from HPIA.' -Icon 'Exclamation' -Buttons 'OK'
                    Close-ADTSession -Exitcode $RunCommand.Exitcode
		        }

}


##================================================
## MARK: Initialization
##================================================

# Set strict error handling across entire operation.
$ErrorActionPreference = [System.Management.Automation.ActionPreference]::Stop
$ProgressPreference = [System.Management.Automation.ActionPreference]::SilentlyContinue
Set-StrictMode -Version 1

# Import the module and instantiate a new session.
try
{
    $moduleName = if ([System.IO.File]::Exists("$PSScriptRoot\PSAppDeployToolkit\PSAppDeployToolkit.psd1"))
    {
        Get-ChildItem -LiteralPath $PSScriptRoot\PSAppDeployToolkit -Recurse -File | Unblock-File -ErrorAction Ignore
        "$PSScriptRoot\PSAppDeployToolkit\PSAppDeployToolkit.psd1"
    }
    else
    {
        'PSAppDeployToolkit'
    }
    Import-Module -FullyQualifiedName @{ ModuleName = $moduleName; Guid = '8c3c366b-8606-4576-9f2d-4051144f7ca2'; ModuleVersion = '4.0.6' } -Force
    try
    {
        $iadtParams = Get-ADTBoundParametersAndDefaultValues -Invocation $MyInvocation
        $adtSession = Open-ADTSession -SessionState $ExecutionContext.SessionState @adtSession @iadtParams -PassThru
    }
    catch
    {
        Remove-Module -Name PSAppDeployToolkit* -Force
        throw
    }
}
catch
{
    $Host.UI.WriteErrorLine((Out-String -InputObject $_ -Width ([System.Int32]::MaxValue)))
    exit 60008
}


##================================================
## MARK: Invocation
##================================================

try
{
    Get-Item -Path $PSScriptRoot\PSAppDeployToolkit.* | & {
        process
        {
            Get-ChildItem -LiteralPath $_.FullName -Recurse -File | Unblock-File -ErrorAction Ignore
            Import-Module -Name $_.FullName -Force
        }
    }
    & "$($adtSession.DeploymentType)-ADTDeployment"
    Close-ADTSession
}
catch
{
    Write-ADTLogEntry -Message ($mainErrorMessage = Resolve-ADTErrorRecord -ErrorRecord $_) -Severity 3
    Show-ADTDialogBox -Text $mainErrorMessage -Icon Stop | Out-Null
    Close-ADTSession -ExitCode 60001
}
finally
{
    Remove-Module -Name PSAppDeployToolkit* -Force
}

